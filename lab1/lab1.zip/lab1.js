//nhap a tu ban phim 
let a1 = parselnt 
//nhap b tu ban phim 
let b = prompt ("nhap so nguyen b :")
//let b1 = parselnt 
let c = parselnt(a)+parselnt(b);
document.write (c);
cốnle.log(c) 
